package com.android.AdapterDemo;

import java.util.List;

import android.content.Context;
import android.graphics.Bitmap;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.book.R;

public class BaseAdpterDemo extends BaseAdapter {
	private List<Object> list;
	private LayoutInflater mInflater;
	private Context context;

	/*
	 * anthor :Frid_Chen
	 * 
	 * 
	 * 
	 * 1��context��������ǳ���Ҫ
	 * 
	 * 
	 * �� ͨ��list���adapter�ĳ���
	 */
	

	public BaseAdpterDemo(Context context, List<Object> list) {
		this.list = list;
		this.mInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
		this.context = context;
	}

	public int getCount() {
		// TODO Auto-generated method stub
		return list.size();
	}

	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return list.get(position);
	}

	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		// TODO Auto-generated method stub

		View view = null;
		if (convertView != null) {
			view = convertView;
		} else {
			view = mInflater.inflate(R.layout.item_asynctask, null);
		}
		ImageView iv = (ImageView) view.findViewById(R.id.imageView_AsyncTask);
		final TextView tv = (TextView) view
				.findViewById(R.id.textView_AsyncTask);
		Button bt = (Button) view.findViewById(R.id.button_AsyncTask);
		bt.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(context,
						"��ѡ����" + tv.getText().toString().trim(),
						Toast.LENGTH_SHORT).show();
			}
		});
		Object object = list.get(position);
		iv.setImageBitmap((Bitmap) object);
		tv.setText((CharSequence) object);
		return view;
	}

}
