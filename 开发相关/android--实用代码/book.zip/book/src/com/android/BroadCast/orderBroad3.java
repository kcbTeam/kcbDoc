package com.android.BroadCast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class orderBroad3 extends BroadcastReceiver {

	@Override
	public void onReceive(Context content, Intent intent) {
		// TODO Auto-generated method stub
		Bundle b = getResultExtras(true);
		int xx = b.getInt("test");
		Toast.makeText(content, xx + "", Toast.LENGTH_SHORT).show();
		b.putInt("test", ++xx);

	}

}
