package com.android.BroadCast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

public class orderBroad1 extends BroadcastReceiver {
	@Override
	public void onReceive(Context content, Intent intent) {
		// TODO Auto-generated method stub
		int xx = intent.getIntExtra("test", 10000);
		Toast.makeText(content, xx + "", Toast.LENGTH_SHORT).show();
		Bundle b = new Bundle();
		b.putInt("test", ++xx);
		setResultExtras(b);
	}
}
