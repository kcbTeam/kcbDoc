package com.android.BroadCast;

import android.app.Activity;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.android.book.R;

public class BroadCastTest extends Activity implements OnClickListener {
	private Button mButton1, mButton2, mButton3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_broadcast);
		mButton1 = (Button) this.findViewById(R.id.button_broadcast1);
		mButton2 = (Button) this.findViewById(R.id.button_broadcast2);
		mButton3 = (Button) this.findViewById(R.id.button_broadcast3);
		mButton1.setOnClickListener(this);
		mButton2.setOnClickListener(this);
		mButton3.setOnClickListener(this);
		IntentFilter filter = new IntentFilter("Frid_Chen");
		BroadCast2 tt = new BroadCast2();
		registerReceiver(tt, filter);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.button_broadcast1:
			Intent intent = new Intent();
			intent.setAction("android.basic.xxx");
			sendBroadcast(intent);
			break;
		case R.id.button_broadcast2:
			Intent intent2 = new Intent();
			intent2.setAction("Frid_Chen");
			sendBroadcast(intent2);
			break;
		case R.id.button_broadcast3:
			Intent intent3 = new Intent();
			intent3.putExtra("test", 1);
			intent3.setAction("com.android.order_text");
			sendOrderedBroadcast(intent3, null);
			break;
		default:
			break;
		}
	}
}
