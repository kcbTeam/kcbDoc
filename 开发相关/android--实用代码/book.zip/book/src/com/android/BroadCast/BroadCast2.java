package com.android.BroadCast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.widget.Toast;

public class BroadCast2 extends BroadcastReceiver {

	@Override
	public void onReceive(Context mContext, Intent intent) {
		// TODO Auto-generated method stub
		if (intent.getAction().equals("Frid_Chen")) {
			Toast.makeText(mContext, "���ͳɹ��㲥2", Toast.LENGTH_LONG).show();
			System.gc();
		}
	}
}
