package com.android.XMLParser;

import java.io.InputStream;
import java.util.List;

import com.android.book.R;

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;

public class XMLParserDemo extends Activity {
	private static final String TAG = "XML";
	private BookParser parser;
	private List<Book> books;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_xmlparser);
	}

	public void readBtn_sax(View v) {
		try {
			InputStream is = getAssets().open("books.xml");
			parser = new SaxBookParser();
			books = parser.parse(is);
			for (Book book : books) {
				// book.toString();
				Log.i(TAG, book.toString());
			}
		} catch (Exception e) {
			e.printStackTrace();
			Log.e(TAG, e.getMessage());
		}
	}

	public void readBtn_pull(View v) {
		try {
			InputStream is = getAssets().open("books.xml");
			parser = new PullBookParser();
			books = parser.parse(is);
			for (Book book : books) {
				Log.i(TAG, book.toString());
			}
		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		}
	}

	public void readBtn_dom(View v) {
		try {
			InputStream is = getAssets().open("books.xml");
			parser = new DomBookParser();
			books = parser.parse(is);
			for (Book book : books) {
				Log.i(TAG, book.toString());
			}
		} catch (Exception e) {
			Log.e(TAG, e.getMessage());
		}
	}

	public void writeBtn(View v) {
		new Thread(new Runnable() {
			public void run() {
				// TODO Auto-generated method stub
				try {
					List<Contact> contacts = XmlwebData
							.getData("http://10.0.2.2:8080/AsyncTaskTest/list.xml");
					for (int i = 0; i < contacts.size(); i++) {
						System.out.println(contacts.get(i).getImage());
					}
					System.out.println();
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}).start();
	}
}
