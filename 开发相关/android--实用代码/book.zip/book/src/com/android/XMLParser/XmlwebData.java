package com.android.XMLParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import org.xmlpull.v1.XmlPullParser;

import android.annotation.SuppressLint;
import android.util.Xml;

/*
 * author��������
 * ͨ��http����������xml��Դ
 * ��xml��Դת����inputStream
 * ���ö�Ӧ�ķ�����ɽ���
 * 
 * */

public class XmlwebData {

	@SuppressLint("UseValueOf")
	public static List<Contact> getData(String path) throws Exception {
		List<Contact> contacts = null;
		URL url = new URL(path);
		HttpURLConnection conn = (HttpURLConnection) url.openConnection();
		
		conn.setConnectTimeout(5000);
		if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
			InputStream inputstream = conn.getInputStream();
			System.out.println("�������ӳɹ�");

			Contact contact = null;
			XmlPullParser parser = Xml.newPullParser();
			parser.setInput(inputstream, "UTF-8");
			int eventType = parser.getEventType();
			while ((eventType = parser.next()) != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.START_TAG:
					if (parser.getName().equals("contacts")) {
						contacts = new ArrayList<Contact>();
					} else if (parser.getName().equals("contact")) {
						contact = new Contact();
						contact.setId(Integer.valueOf(parser
								.getAttributeValue(0)));
					} else if (parser.getName().equals("name")) {
						contact.setName(parser.nextText());
					} else if (parser.getName().equals("image")) {
						contact.setImage(parser.getAttributeValue(0));
						System.out.println(parser.getAttributeValue(0));
					}
					break;

				case XmlPullParser.END_TAG:
					if (parser.getName().equals("contact")) {
						contacts.add(contact);
					}
					break;
				}
			}

		}
		return contacts;
	}
}