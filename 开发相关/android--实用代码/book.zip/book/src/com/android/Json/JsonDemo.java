package com.android.Json;

import com.android.book.R;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class JsonDemo extends Activity {
	private Button button1, button2, button3, button4;
	private String strJson1, strJson2, strJson3, strJson4;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_json);
		init();
	}

	private void init() {
		// TODO Auto-generated method stub
		button1 = (Button) findViewById(R.id.jsonreader);
		button2 = (Button) findViewById(R.id.gson);
		button3 = (Button) findViewById(R.id.gson2);
		button4 = (Button) findViewById(R.id.jsonobject);
		button1.setOnClickListener(new buttonlistener());
		button2.setOnClickListener(new buttonlistener());
		button3.setOnClickListener(new buttonlistener());
		button4.setOnClickListener(new buttonlistener());
		strJson1 = "[{\"firstName\": \"Brett\",\"lastName\":\"McLaughlin\", \"email\": \"aaaa\" }, "
				+ "{\"firstName\": \"Jason\", \"lastName\":\"Hunter\",\"email\":\"bbbb\"},"
				+ "{\"firstName\":\"Elliotte\",\"lastName\":\"Harold\",\"email\":\"cccc\"}]";
		strJson2 = "{\"firstName\": \"Brett\",\"lastName\":\"McLaughlin\"}";

		strJson4 = "{\"people\": [{\"firstName\": \"Brett\",\"lastName\":\"McLaughlin\", \"email\": \"aaaa\" }, "
				+ "{\"firstName\": \"Jason\", \"lastName\":\"Hunter\",\"email\":\"bbbb\"},"
				+ "{\"firstName\":\"Elliotte\",\"lastName\":\"Harold\",\"email\":\"cccc\"}]}";
	}

	class buttonlistener implements OnClickListener {
		public void onClick(View v) {
			// TODO Auto-generated method stub
			switch (v.getId()) {
			case R.id.jsonreader:
				jsonreader.fun(strJson1);
				break;
			case R.id.gson:
				gson.fun(strJson2);
				break;
			case R.id.gson2:
				gson2.fun(strJson1);
				break;
			case R.id.jsonobject:
				jsonobject.fun(strJson4);
				break;
			}
		}
	}
}
