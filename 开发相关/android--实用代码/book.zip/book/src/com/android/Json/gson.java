package com.android.Json;

import com.google.gson.Gson;

public class gson {
	public static void fun(String str) {
		Gson gson = new Gson();
		User user = gson.fromJson(str, User.class);
		System.out.println(user);
	}
}
