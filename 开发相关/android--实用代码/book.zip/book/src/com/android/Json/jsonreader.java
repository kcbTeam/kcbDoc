package com.android.Json;

import java.io.StringReader;
import com.google.gson.stream.JsonReader;

public class jsonreader {
	public static void fun(String str) {
		try {
			JsonReader reader = new JsonReader(new StringReader(str));
			reader.beginArray();
			while (reader.hasNext()) {
				reader.beginObject();
				while (reader.hasNext()) {
					String tagname = reader.nextName();
					if (tagname.equals("firstName")) {
						System.out.println(reader.nextString());
					} else if (tagname.equals("lastName")) {
						System.out.println(reader.nextString());
					} else if (tagname.equals("email")) {
						System.out.println(reader.nextString());
					}
				}
				reader.endObject();
			}
			reader.endArray();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
