package com.android.Json;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class jsonobject {
	public static void fun(String str) {
		try {
			JSONObject jo = new JSONObject(str);
			JSONArray jsonArray = (JSONArray) jo.get("people");
			for (int i = 0; i < jsonArray.length(); ++i) {
				JSONObject o = (JSONObject) jsonArray.get(i);
				System.out.println("firstName:" + o.getString("firstName")
						+ "," + "lastName:" + o.getString("lastName")
						+ o.getString("email"));
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
