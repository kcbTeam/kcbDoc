package com.android.Json;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Iterator;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

public class gson2 {
	public static void fun(String str) {
		Type listType = new TypeToken<ArrayList<User>>() {
		}.getType();
		Gson gson = new Gson();
		ArrayList<User> users = gson.fromJson(str, listType);
		for (Iterator iterator = users.iterator(); iterator.hasNext();) {
			User user = (User) iterator.next();
			System.out.println(user);

		}
	}

}
