package com.android.refresh;

import com.android.book.R;
import com.android.refresh.PullToRefreshView.OnFooterRefreshListener;
import com.android.refresh.PullToRefreshView.OnHeaderRefreshListener;

import android.app.Activity;
import android.os.Bundle;
import android.widget.GridView;

public class TestGridView extends Activity implements OnHeaderRefreshListener,
		OnFooterRefreshListener {
	PullToRefreshView mPullToRefreshView;
	GridView mGridView;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.test_gridview);

		mPullToRefreshView = (PullToRefreshView) findViewById(R.id.main_pull_refresh_view);
		mGridView = (GridView) findViewById(R.id.gridview);
		mGridView.setAdapter(new DataAdapter(this));
		mPullToRefreshView.setOnHeaderRefreshListener(this);
		mPullToRefreshView.setOnFooterRefreshListener(this);

	}

	public void onFooterRefresh(PullToRefreshView view) {
		mPullToRefreshView.postDelayed(new Runnable() {

			public void run() {
				mPullToRefreshView.onFooterRefreshComplete();
			}
		}, 1000);
	}

	
	public void onHeaderRefresh(PullToRefreshView view) {
		mPullToRefreshView.postDelayed(new Runnable() {

			
			public void run() {
				
				mPullToRefreshView.onHeaderRefreshComplete();
			}
		}, 1000);

	}
}
