package com.android.refresh;

import com.android.book.R;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;

public class DataAdapter extends BaseAdapter{
		Context mContext;
		public DataAdapter(Context context){
			mContext = context;
		}
		
		public int getCount() {
			return 20;
		}

		
		public Object getItem(int position) {
			return position;
		}

		
		public long getItemId(int position) {
			return position;
		}

		
		public View getView(int position, View convertView, ViewGroup parent) {
			if(convertView == null){
				convertView = View.inflate(mContext, R.layout.grid_item, null);		
			}
			return convertView;
		}
	}