package com.android.main;

/*
 * 
 * author:fird_chen
 * */

import com.android.AsyncTask.AsyncTaskNew;
import com.android.BroadCast.BroadCastTest;
import com.android.Json.JsonDemo;
import com.android.XMLParser.XMLParserDemo;
import com.android.book.ActionBarActivity;
import com.android.book.AddView;
import com.android.book.AsyncTaskActivity;
import com.android.book.AutoCompleteTextViewActivity;
import com.android.book.CheckBoxActivity;
import com.android.book.DatePickerActivity;
import com.android.book.DialogAll;
import com.android.book.DrawAbleActivity;
import com.android.book.EditTextActivity;
import com.android.book.ExecutorServiceActivity;
import com.android.book.ExpandableListActivity;
import com.android.book.GridViewActivity;
import com.android.book.ImageButtonActivity;
import com.android.book.ImageShowActivity;
import com.android.book.ImageViewActivity;
import com.android.book.ListViewActivity;
import com.android.book.NotificationTest;
import com.android.book.ProgressBarActivity;
import com.android.book.R;
import com.android.book.RadioGroupActivity;
import com.android.book.RatingBarActivity;
import com.android.book.SeekBarActivity;
import com.android.book.SpinnerActivity;
import com.android.book.TabDemoActivity;
import com.android.book.TextViewActivity;
import com.android.book.TimePickerActivity;
import com.android.book.ToggleButtonView;
import com.android.book.button;
import com.android.io.IOTest;
import com.android.network.NetWork;
import com.android.refresh.RefreshActivity;
import com.android.service.StratServiceTest;
import com.example.animation.AnimationExampleActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class Book extends Activity {
	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		find_and_modify_button();
	}

	private void find_and_modify_button() {
		Button button = (Button) findViewById(R.id.button_xx);
		button.setOnClickListener(button_listener);
		Button Togglebutton = (Button) findViewById(R.id.ToggleButton);
		Togglebutton.setOnClickListener(Togglebutton_listener);
		Button text_view_button = (Button) findViewById(R.id.text_view_button);
		text_view_button.setOnClickListener(text_view_button_listener);

		Button edit_view_button = (Button) findViewById(R.id.edit_view_button);
		edit_view_button.setOnClickListener(edit_view_button_listener);

		Button check_box_button = (Button) findViewById(R.id.check_box_button);
		check_box_button.setOnClickListener(check_box_button_listener);

		Button radio_group_button = (Button) findViewById(R.id.radio_group_button);
		radio_group_button.setOnClickListener(radio_group_button_listener);

		Button spinner_button = (Button) findViewById(R.id.spinner_button);
		spinner_button.setOnClickListener(spinner_button_listener);

		Button auto_complete_button = (Button) findViewById(R.id.auto_complete_button);
		auto_complete_button.setOnClickListener(auto_complete_button_listener);

		Button date_picker_button = (Button) findViewById(R.id.date_picker_button);
		date_picker_button.setOnClickListener(date_picker_button_listener);

		Button time_picker_button = (Button) findViewById(R.id.time_picker_button);
		time_picker_button.setOnClickListener(time_picker_button_listener);

		Button progress_bar_button = (Button) findViewById(R.id.progress_bar_button);
		progress_bar_button.setOnClickListener(progress_bar_button_listener);

		Button seek_bar_button = (Button) findViewById(R.id.seek_bar_button);
		seek_bar_button.setOnClickListener(seek_bar_button_listener);

		Button rating_bar_button = (Button) findViewById(R.id.rating_bar_button);
		rating_bar_button.setOnClickListener(rating_bar_button_listener);

		Button image_view_button = (Button) findViewById(R.id.image_view_button);
		image_view_button.setOnClickListener(image_view_button_listener);

		Button image_button_button = (Button) findViewById(R.id.image_button_button);
		image_button_button.setOnClickListener(image_button_button_listener);

		Button image_show_button = (Button) findViewById(R.id.image_show_button);
		image_show_button.setOnClickListener(image_show_button_listener);

		Button grid_view_button = (Button) findViewById(R.id.grid_view_button);
		grid_view_button.setOnClickListener(grid_view_button_listener);

		Button tab_demo_button = (Button) findViewById(R.id.tab_demo_button);
		tab_demo_button.setOnClickListener(tab_demo_button_listener);

		Button listview_button = (Button) findViewById(R.id.listview_button);
		listview_button.setOnClickListener(listview_button_listener);

		Button animation_demo_button = (Button) findViewById(R.id.animation_demo_button);
		animation_demo_button
				.setOnClickListener(new animation_demo_button_listener01());
		Button Dialog_button = (Button) findViewById(R.id.dialog);
		Dialog_button.setOnClickListener(Dialog_button_listener);
		Button mExpandableList = (Button) findViewById(R.id.ExpandableList);
		mExpandableList.setOnClickListener(mExpandableList_listener);

		Button mAddView = (Button) findViewById(R.id.button_add_view);
		mAddView.setOnClickListener(mAddViewList_listener);

		Button mActionBar = (Button) findViewById(R.id.button_actionbar);
		mActionBar.setOnClickListener(mActionBar_listener);

		Button mDrawAble = (Button) findViewById(R.id.button_Drawable);
		mDrawAble.setOnClickListener(mDrawAble_listener);

		Button mAsyncTask = (Button) findViewById(R.id.button_asynctask);
		mAsyncTask.setOnClickListener(mAsyncTask_listener);

		Button mExecutorService = (Button) findViewById(R.id.button_ExecutorService);
		mExecutorService.setOnClickListener(mExecutorService_listener);

		Button Butto_refresh = (Button) findViewById(R.id.button_refresh);
		Butto_refresh.setOnClickListener(Butto_refresh_listener);

		Button Butto_Service = (Button) findViewById(R.id.button_service_test);
		Butto_Service.setOnClickListener(Butto_Service_listener);

		Button Butto_io = (Button) findViewById(R.id.button_io);
		Butto_io.setOnClickListener(Butto_io_listener);

		Button Butto_network = (Button) findViewById(R.id.button_network);
		Butto_network.setOnClickListener(Butto_network_listener);

		Button Butto_broadcast = (Button) findViewById(R.id.button_broadcast);
		Butto_broadcast.setOnClickListener(Butto_broadcast_listener);

		Button Butto_notification = (Button) findViewById(R.id.button_notification);
		Butto_notification.setOnClickListener(Butto_notification_listener);

		Button Butto_AsyncTask_new = (Button) findViewById(R.id.button_asynctask_new);
		Butto_AsyncTask_new.setOnClickListener(Butto_AsyncTask_new_listener);

		Button Butto_XML = (Button) findViewById(R.id.button_XML);
		Butto_XML.setOnClickListener(Butto_XML_listener);

		Button Butto_Json = (Button) findViewById(R.id.button_Json);
		Butto_Json.setOnClickListener(Butto_Json_listener);

		// �ڶ������ü����ķ���
		// animation_demo_button.setOnClickListener(animation_demo_button_listener);
		// ���������ü����ķ���
		/*
		 * animation_demo_button.setOnClickListener(new OnClickListener() {
		 * 
		 * public void onClick(View v) { // TODO Auto-generated method stub
		 * Intent intent = new Intent(BOOKActivity.this,
		 * AnimationExampleActivity.class); startActivity(intent); } });
		 */
	}

	private Button.OnClickListener button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(Book.this, button.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener listview_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(Book.this, ListViewActivity.class);
			startActivity(intent);
		}
	};

	public class animation_demo_button_listener01 implements OnClickListener {

		public void onClick(View v) {
			// TODO Auto-generated method stub
			Intent intent = new Intent(Book.this,
					AnimationExampleActivity.class);
			startActivity(intent);

		}

	}

	private Button.OnClickListener animation_demo_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent(Book.this,
					AnimationExampleActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener Togglebutton_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ToggleButtonView.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener text_view_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, TextViewActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener edit_view_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, EditTextActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener check_box_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, CheckBoxActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener radio_group_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, RadioGroupActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener spinner_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, SpinnerActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener auto_complete_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, AutoCompleteTextViewActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener date_picker_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, DatePickerActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener time_picker_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, TimePickerActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener progress_bar_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ProgressBarActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener seek_bar_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, SeekBarActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener rating_bar_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, RatingBarActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener image_view_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ImageViewActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener image_button_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ImageButtonActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener image_show_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ImageShowActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener grid_view_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, GridViewActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener tab_demo_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, TabDemoActivity.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Dialog_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, DialogAll.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener mExpandableList_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ExpandableListActivity.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener mAddViewList_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, AddView.class);
			startActivity(intent);

		}
	};
	private Button.OnClickListener mActionBar_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ActionBarActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener mDrawAble_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, DrawAbleActivity.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener mAsyncTask_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, AsyncTaskActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener mExecutorService_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, ExecutorServiceActivity.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_refresh_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, RefreshActivity.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener Butto_Service_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, StratServiceTest.class);
			startActivity(intent);
		}
	};

	private Button.OnClickListener Butto_io_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, IOTest.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_network_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, NetWork.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_broadcast_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, BroadCastTest.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_notification_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, NotificationTest.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_AsyncTask_new_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, AsyncTaskNew.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_XML_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, XMLParserDemo.class);
			startActivity(intent);
		}
	};
	private Button.OnClickListener Butto_Json_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			Intent intent = new Intent();
			intent.setClass(Book.this, JsonDemo.class);
			startActivity(intent);
		}
	};
}
