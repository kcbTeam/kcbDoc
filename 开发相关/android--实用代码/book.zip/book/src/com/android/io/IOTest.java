package com.android.io;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import com.android.book.R;

/**
 * author:Frid_Chen version:1.0
 * 
 */

public class IOTest extends Activity implements OnClickListener {
	private Button Button1, Button2, Button3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_iotest);
		Button1 = (Button) this.findViewById(R.id.button_filetest);
		Button1.setOnClickListener(this);
		Button2 = (Button) this.findViewById(R.id.button_sdtest);
		Button2.setOnClickListener(this);
		Button3 = (Button) this.findViewById(R.id.button_sdfile);
		Button3.setOnClickListener(this);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.button_filetest:
			Intent intent = new Intent(IOTest.this, FileTest.class);
			startActivity(intent);
			break;
		case R.id.button_sdtest:

			Intent intent2 = new Intent(IOTest.this, SDTest.class);
			startActivity(intent2);
			break;
		case R.id.button_sdfile:

			Intent intent3 = new Intent(IOTest.this, SDFileExplorer.class);
			startActivity(intent3);
			break;
		}

	}
}
