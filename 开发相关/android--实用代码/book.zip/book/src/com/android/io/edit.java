package com.android.io;

/**
 * 
 * author:Frid_Chen
 * version:1.0
 * 
 */
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import com.android.book.R;

public class edit extends Activity {
	private EditText et = null;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_edit);
		Intent intent = getIntent();
		String xx = intent.getStringExtra("yy");
		et = (EditText) this.findViewById(R.id.edit_textview);
		et.setText(xx);

	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		// TODO Auto-generated method stub
		super.onActivityResult(requestCode, resultCode, data);
	}
}
