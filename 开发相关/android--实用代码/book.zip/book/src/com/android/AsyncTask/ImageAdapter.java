package com.android.AsyncTask;

import java.io.File;
import java.util.List;

import android.content.Context;
import android.net.Uri;
import android.os.AsyncTask;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.android.book.R;

public class ImageAdapter extends BaseAdapter {

	protected static final int SUCCESS_GET_IMAGE = 0;
	private Context context;
	private List<Contact> contacts;
	private File cache;
	private LayoutInflater mInflater;

	// �Լ�����Ĺ��캯��
	public ImageAdapter(Context context, List<Contact> contacts, File cache) {
		this.context = context;
		this.contacts = contacts;
		this.cache = cache;
		System.out.println("������adapter");
		mInflater = (LayoutInflater) context
				.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	}

	public int getCount() {
		return contacts.size();
	}

	public Object getItem(int position) {
		return contacts.get(position);
	}

	public long getItemId(int position) {
		return position;
	}

	public View getView(int position, View convertView, ViewGroup parent) {
		// 1��ȡitem,�ٵõ��ؼ�
		// 2 ��ȡ����
		// 3�����ݵ�item
		View view = null;
		if (convertView != null) {
			view = convertView;
		} else {
			view = mInflater.inflate(R.layout.item_asynctask, null);
		}
		ImageView iv_header = (ImageView) view
				.findViewById(R.id.imageView_AsyncTask);
		final TextView tv_name = (TextView) view
				.findViewById(R.id.textView_AsyncTask);
		Button btttt = (Button) view.findViewById(R.id.button_AsyncTask);
		btttt.setOnClickListener(new View.OnClickListener() {
			public void onClick(View v) {
				// TODO Auto-generated method stub
				Toast.makeText(context,
						"��ѡ����" + tv_name.getText().toString().trim(),
						Toast.LENGTH_SHORT).show();
			}
		});

		Contact contact = contacts.get(position);
		// �첽�ļ���ͼƬ (�̳߳� + Handler ) ---> AsyncTask
		asyncloadImage(iv_header, contact.image);
		tv_name.setText(contact.name);
		return view;
	}

	private void asyncloadImage(ImageView iv_header, String path) {
		ContactService service = new ContactService();
		AsyncImageTask task = new AsyncImageTask(service, iv_header);
		task.execute(path);
	}

	private final class AsyncImageTask extends AsyncTask<String, Integer, Uri> {

		private ContactService service;
		private ImageView iv_header;

		public AsyncImageTask(ContactService service, ImageView iv_header) {
			this.service = service;
			this.iv_header = iv_header;
		}

		// ��̨���е����߳����߳�
		@Override
		protected Uri doInBackground(String... params) {
			try {
				return service.getImageURI(params[0], cache);
			} catch (Exception e) {
				e.printStackTrace();
			}
			return null;
		}

		// ���������ui�߳���ִ��
		@Override
		protected void onPostExecute(Uri result) {
			super.onPostExecute(result);
			// ���ͼƬ�İ�
			if (iv_header != null && result != null) {
				iv_header.setImageURI(result);
			}
		}
	}
}