package com.android.service;

import android.app.IntentService;
import android.content.Intent;

public class SecondIntentService extends IntentService {
	public SecondIntentService() {
		super("test");
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void onHandleIntent(Intent intent) {
		// TODO Auto-generated method stub
		long endTime = System.currentTimeMillis() + 4 * 2000;
		System.out.println("onStart");
		while (System.currentTimeMillis() < endTime) {
			try {
				wait(endTime - System.currentTimeMillis());

			} catch (Exception e) {
				// TODO: handle exception
			}
		}
		System.out.println("��ʱ����ִ�����");
	}
}
