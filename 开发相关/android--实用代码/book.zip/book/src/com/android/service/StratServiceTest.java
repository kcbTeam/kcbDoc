package com.android.service;

import android.app.Activity;
import android.app.Service;
import android.content.ComponentName;
import android.content.Intent;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

import com.android.service.FirstService.MyBinder;

import com.android.book.R;

public class StratServiceTest extends Activity implements OnClickListener {
	private Intent intent = new Intent();;
	private Button mButton1, mButton2, mButton3, mButton4;
	private MyBinder binder;
	private ServiceConnection conn = new ServiceConnection() {

		public void onServiceConnected(ComponentName name, IBinder service) {
			// TODO Auto-generated method stub
			System.out.println("�󶨳ɹ���");
			binder = (MyBinder) service;
		}

		public void onServiceDisconnected(ComponentName name) {
			// TODO Auto-generated method stub
			System.out.print("Disconnect");
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.startservicetest);
		intent.setAction("com.android.service.FirstService");
		mButton1 = (Button) this.findViewById(R.id.startservicetest_start);
		mButton2 = (Button) this.findViewById(R.id.startservicetest_stop);
		mButton3 = (Button) this.findViewById(R.id.startservicetest_get);
		mButton4 = (Button) this.findViewById(R.id.intentservice_test);
		mButton1.setOnClickListener(this);
		mButton2.setOnClickListener(this);
		mButton3.setOnClickListener(this);
		mButton4.setOnClickListener(this);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.startservicetest_start:
			bindService(intent, conn, Service.BIND_AUTO_CREATE);
			// startService(intent);
			break;
		case R.id.startservicetest_stop:
			stopService(intent);
			unbindService(conn);
			break;
		case R.id.startservicetest_get:
			Toast.makeText(StratServiceTest.this, binder.getcount() + "",
					Toast.LENGTH_SHORT).show();
			break;
		case R.id.intentservice_test:
			Intent intent = new Intent(this, SecondIntentService.class);
			intent.setAction("com.android.service.secondService");
			startService(intent);
			break;
		default:
			break;
		}
	}

}
