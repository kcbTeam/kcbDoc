package com.android.service;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;

public class FirstService extends Service {
	private Boolean quit=new Boolean(false);
	private int count;
	private MyBinder binder = new MyBinder();

	public class MyBinder extends Binder {
		public int getcount() {
			return count;
		}
	}

	// ����ʵ�ֵķ���
	@Override
	public IBinder onBind(Intent intent) {
		// TODO Auto-generated method stub
		return binder;
	}

	// Service������ʱ�ص��÷���
	@Override
	public void onCreate() {
		// TODO Auto-generated method stub
		super.onCreate();
		System.out.println("������");
		new Thread() {
			@Override
			public void run() {
				while (!quit) {
					try {
						Thread.sleep(1000);
					} catch (Exception e) {
					}
					count++;
				}
			};
		}.start();
	}

	// // ��service������ʱ���õķ���
	// @Override
	// public int onStartCommand(Intent intent, int flags, int startId) {
	// // TODO Auto-generated method stub
	// System.out.println("��ʼ��");
	//
	// return super.onStartCommand(intent, flags, startId);
	// }

	// ��service������ʱ�ص��ķ���
	@Override
	public void onDestroy() {
		// TODO Auto-generated method stub
		System.out.println("������");
		this.quit = true;
		super.onDestroy();
	}

	@Override
	public boolean onUnbind(Intent intent) {
		// TODO Auto-generated method stub
		System.out.println("�����");
		return super.onUnbind(intent);

	}

}
