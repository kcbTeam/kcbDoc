package com.android.network;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.android.book.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

public class HttpUrlConnection_get extends Activity {
	private TextView mTextView = null;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			if (msg.obj != null) {
				mTextView.setText((CharSequence) msg.obj);
			} else {
				Toast.makeText(HttpUrlConnection_get.this, "��ȡ����",
						Toast.LENGTH_SHORT).show();
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.http1);
		mTextView = (TextView) findViewById(R.id.TextView_HTTP);

		new Thread(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub
				String httpUrl = "http://www.baidu.com";
				String resultData = null;
				URL url = null;
				try {
					url = new URL(httpUrl);

				} catch (MalformedURLException e) {
					// TODO: handle exception
					e.printStackTrace();
				}
				if (url != null) {
					try {
						HttpURLConnection urlConn = (HttpURLConnection) url
								.openConnection();
						InputStreamReader in = new InputStreamReader(urlConn
								.getInputStream());
						BufferedReader buffer = new BufferedReader(in);
						String inputLine = null;
						while ((inputLine = buffer.readLine()) != null) {
							resultData += inputLine + "\n";

						}

						urlConn.disconnect();
						Message msg = new Message();
						msg.obj = resultData;
						myHandler.sendMessage(msg);

					} catch (IOException e) {
						// TODO: handle exception
						Log.e("HttpUrlConnection", "IOException");
					}
				}
			}
		}).start();

	}
}
