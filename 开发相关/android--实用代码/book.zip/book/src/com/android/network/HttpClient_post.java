package com.android.network;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

import com.android.book.R;

public class HttpClient_post extends Activity {
	/** Called when the activity is first created. */
	TextView mTextView;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			mTextView.setText((CharSequence) msg.obj);
		};
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.http1);
		mTextView = (TextView) this.findViewById(R.id.TextView_HTTP);

		new Thread(new Runnable() {

			public void run() {
				// TODO Auto-generated method stub
				// http��ַ
				String httpUrl = "http://www.baidu.com";
				// HttpPost���Ӷ���
				HttpPost httpPost = new HttpPost(httpUrl);
				// ʹ��NameValuePair������Ҫ���ݵ�Post����
				List<NameValuePair> params = new ArrayList<NameValuePair>();
				PostParam pp= new PostParam();
				// ����Ҫ���ݵĲ���
				pp.setAuthInfo("username", "password");
				params.add(new BasicNameValuePair("par",
						"HttpClient_android_Post"));
				try {
					// �����ַ���
					HttpEntity httpentity = new UrlEncodedFormEntity(params,
							"gb2312");
					// ����httpRequest
					httpPost.setEntity(httpentity);
					// ȡ��Ĭ�ϵ�HttpClient
					HttpClient httpclient = new DefaultHttpClient();
					// ȡ��HttpResponse
					HttpResponse httpResponse = httpclient.execute(httpPost);
					// HttpStatus.SC_OK��ʾ���ӳɹ�
					if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
						// ȡ�÷��ص��ַ���
						String strResult = EntityUtils.toString(httpResponse
								.getEntity());
						// mTextView.setText(strResult);
						Message msg = new Message();
						msg.obj = strResult;
						myHandler.sendMessage(msg);
					} else {
						// mTextView.setText("�������!");
					}
				} catch (ClientProtocolException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (IOException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (Exception e) {
					// mTextView.setText(e.getMessage().toString());
				}

			}
		}).start();

	}

}
