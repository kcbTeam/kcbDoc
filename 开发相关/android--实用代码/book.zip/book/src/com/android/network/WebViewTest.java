package com.android.network;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;

import com.android.book.R;

public class WebViewTest extends Activity implements OnClickListener {
	private Button btn;
	private EditText et;
	private WebView wv;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			wv.loadDataWithBaseURL(null, msg.obj.toString(), "text/html",
					"utf-8", null);
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_webview);
		btn = (Button) this.findViewById(R.id.webview_load);
		et = (EditText) this.findViewById(R.id.webview_edittext);
		wv = (WebView) this.findViewById(R.id.webview);
		btn.setOnClickListener(this);
		new Thread(new Runnable() {
			

			public void run() {
				// TODO Auto-generated method stub
				String httpUrl = "http://www.baidu.com";
				// HttpGet���Ӷ���
				HttpGet httpGet = new HttpGet(httpUrl);
				try {
					// ȡ��HttpClient����
					HttpClient httpclient = new DefaultHttpClient();
					// ����HttpClient��ȡ��HttpResponse
					HttpResponse httpResponse = httpclient.execute(httpGet);
					// ����ɹ�
					if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
						// ȡ�÷��ص��ַ���
						String strResult = EntityUtils.toString(httpResponse
								.getEntity());
						Message msg = new Message();
						msg.obj = strResult;
						myHandler.sendMessage(msg);

					} else {
						// mTextView.setText("�������!");
					}
				} catch (ClientProtocolException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (IOException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (Exception e) {
					// mTextView.setText(e.getMessage().toString());
				}
			}
		}).start();
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.webview_load:
			wv.setWebViewClient(new WebViewClient() {
				@Override
				public void onPageStarted(WebView view, String url,
						Bitmap favicon) {

					super.onPageStarted(view, url, favicon);
				}
			});
			wv.loadUrl(et.getText().toString().trim());
			break;
		default:
			wv.loadUrl("http://www.baidu.com");
			break;
		}

	}

}
