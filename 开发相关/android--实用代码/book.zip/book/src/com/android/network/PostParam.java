package com.android.network;

import java.net.URLEncoder;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.Map.Entry;

public class PostParam extends LinkedHashMap<String, String> {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public PostParam() {
		put("__EVENTTARGET", "");
		put("__EVENTARGUMENT", "");
		put("__LASTFOCUST", "");
		put("rblLoginType", "UserID");
		put("btLogin.x", "0");
		put("btLogin.y", "0");
	}

	@SuppressWarnings("deprecation")
	public void setViewState(String value) {
		put("__VIEWSTATE", URLEncoder.encode(value));
	}

	@SuppressWarnings("deprecation")
	public void setEventValidation(String value) {
		put("__EVENTVALIDATION", URLEncoder.encode(value));
	}

	public void setAuthInfo(String account, String password) {
		put("tbUser", account);
		put("tbPWD", password);
	}

	public static String mapToString(Map<String, String> data) {
		Set<Entry<String, String>> set = data.entrySet();
		StringBuilder sb = new StringBuilder();
		for (Entry<String, String> entry : set) {
			if (sb.length() > 0)
				sb.append("&");
			sb.append(entry.getKey()).append("=").append(entry.getValue());
		}
		return sb.toString();
	}
}
