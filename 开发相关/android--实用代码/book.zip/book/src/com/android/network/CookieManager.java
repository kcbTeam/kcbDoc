package com.android.network;

import java.util.List;
import java.util.Map;

import android.text.TextUtils;

public class CookieManager {
	private static CookieManager sInstance;
	private volatile String mAuthToken;

	private CookieManager() {
	}

	public static synchronized CookieManager getInstance() {
		if (sInstance == null)
			sInstance = new CookieManager();
		return sInstance;
	}

	public synchronized void setAuthToken(String token) {
		mAuthToken = token;
	}

	public void addAuthToken(String token) {
		mAuthToken += "; " + token;
	}

	public String getAuthToken() {
		return mAuthToken;
	}

	public static void clear() {
		// TODO Auto-generated method stub
		if (sInstance != null) {
			sInstance = null;
		}

	}

	public String getInfo(Map<String, List<String>> headers, String key,
			String tag) {
		List<String> fields = headers.get(key);
		String value = "";
		if (fields != null) {
			for (String field : fields) {
				if (TextUtils.isEmpty(tag)) {
					value = field;
				} else if (field.contains(tag)) {
					value = field;
				}
			}
		}
		return value;
	}
}
