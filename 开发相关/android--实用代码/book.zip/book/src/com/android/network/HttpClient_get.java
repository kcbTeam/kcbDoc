package com.android.network;

import java.io.IOException;

import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import com.android.book.R;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TextView;

public class HttpClient_get extends Activity {
	/** Called when the activity is first created. */
	private TextView mTextView;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			mTextView.setText((CharSequence) msg.obj);
		};
	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.http1);
		mTextView = (TextView) this.findViewById(R.id.TextView_HTTP);
		new Thread(new Runnable() {
			public void run() {
				// TODO Auto-generated method stub
				// http��ַ
				String httpUrl = "http://www.baidu.com";
				// HttpGet���Ӷ���
				HttpGet httpGet = new HttpGet(httpUrl);
				try {
					// ȡ��HttpClient����
					HttpClient httpclient = new DefaultHttpClient();
					// ����HttpClient��ȡ��HttpResponse
					HttpResponse httpResponse = httpclient.execute(httpGet);
					// ����ɹ�
					if (httpResponse.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
						// ȡ�÷��ص��ַ���
						String strResult = EntityUtils.toString(httpResponse
								.getEntity());
						Message msg = new Message();
						msg.obj = strResult;
						myHandler.sendMessage(msg);
					} else {
						// mTextView.setText("�������!");
					}
				} catch (ClientProtocolException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (IOException e) {
					// mTextView.setText(e.getMessage().toString());
				} catch (Exception e) {
					// mTextView.setText(e.getMessage().toString());
				}
			}
		}).start();
	}
}