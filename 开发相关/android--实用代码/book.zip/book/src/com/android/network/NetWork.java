package com.android.network;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import com.android.book.R;

import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;

public class NetWork extends Activity implements OnClickListener {
	private ImageView image;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			Bitmap bitmap = null;
			bitmap = (Bitmap) msg.obj;
			image.setImageBitmap(bitmap);
		};
	};
	private Button button1, button2, button3, button4, button5, button6;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_network);
		button1 = (Button) this.findViewById(R.id.btn1);
		button2 = (Button) this.findViewById(R.id.btn2);
		button3 = (Button) this.findViewById(R.id.btn3);
		button4 = (Button) this.findViewById(R.id.btn4);
		button5 = (Button) this.findViewById(R.id.btn5);
		button6 = (Button) this.findViewById(R.id.btn6);
		button6.setOnClickListener(this);
		button5.setOnClickListener(this);
		button4.setOnClickListener(this);
		button3.setOnClickListener(this);
		button2.setOnClickListener(this);
		button1.setOnClickListener(this);
		image = (ImageView) this.findViewById(R.id.imageView);
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		switch (v.getId()) {
		case R.id.btn1:
			Intent intent = new Intent(this, HttpUrlConnection_get.class);
			startActivity(intent);
			break;
		case R.id.btn2:
			Intent intent2 = new Intent(this, HttpUrlConnection_post.class);
			startActivity(intent2);
			break;
		case R.id.btn3:
			Intent intent3 = new Intent(this, HttpClient_get.class);
			startActivity(intent3);
			break;

		case R.id.btn4:
			Intent intent4 = new Intent(this, HttpClient_post.class);
			startActivity(intent4);
			break;

		case R.id.btn5:

			System.out.println("��ʼ��");
			// Bitmap xx =
			// GetNetBitmap.getNetBitmap("http://g.hiphotos.baidu.com/image/w%3D2048%3Bq%3D90/sign=3c628d7760d0f703e6b292dc3cc26a4c/574e9258d109b3de2af33f08cebf6c81800a4c06.jpg");

			ImageView IV = (ImageView) this.findViewById(R.id.imageView);

			new Thread(new Runnable() {

				public void run() {
					// TODO Auto-generated method stub
					URL imageUrl = null;
					Bitmap bitmap = null;
					try {
						imageUrl = new URL(
								"http://g.hiphotos.baidu.com/image/w%3D2048%3Bq%3D90/sign=3c628d7760d0f703e6b292dc3cc26a4c/574e9258d109b3de2af33f08cebf6c81800a4c06.jpg");
					} catch (MalformedURLException e) {
						// TODO: handle exception
					}
					try {
						HttpURLConnection conn = (HttpURLConnection) imageUrl
								.openConnection();
						InputStream in = conn.getInputStream();
						bitmap = BitmapFactory.decodeStream(in);
						in.close();
						Message msg = new Message();
						msg.obj = bitmap;
						System.out.println("�õ�ͼƬ��");
						myHandler.sendMessage(msg);
					} catch (Exception e) {
						// TODO: handle exception
					}
				}
			}).start();

			break;
		case R.id.btn6:
			Intent intent6 = new Intent(this, WebViewTest.class);
			startActivity(intent6);
			break;

		default:
			break;
		}

	}
}
