package com.android.network;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

public class GetNetBitmap {
	private static String url_new;

	public static Bitmap getNetBitmap(String url) {
		url_new = url;
		new Thread(new Runnable() {
			public void run() {
				// TODO Auto-generated method stub
				URL imageUrl = null;
				Bitmap bitmap = null;
				try {
					imageUrl = new URL(url_new);
				} catch (MalformedURLException e) {
					// TODO: handle exception
				}
				try {
					HttpURLConnection conn = (HttpURLConnection) imageUrl
							.openConnection();
					InputStream in = conn.getInputStream();
					bitmap = BitmapFactory.decodeStream(in);
					in.close();

				} catch (Exception e) {
					// TODO: handle exception
				}
			}
		}).start();
		return null;
	}
}
