/*
 * 
 * author:fird_chen
 * */
package com.android.book;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.RadioGroup.OnCheckedChangeListener;
import android.widget.Toast;


public class RadioGroupActivity extends Activity implements
		View.OnClickListener {
	private RadioGroup mRadioGroup;


	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.radio_group);
		setTitle("RadioGroupActivity");
		mRadioGroup = (RadioGroup) findViewById(R.id.menu);
		mRadioGroup.setOnCheckedChangeListener(new OnCheckedChangeListener() {
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				RadioButton Rbtn = (RadioButton) findViewById(checkedId);
				switch (checkedId) {
				case R.id.breakfast:
					Toast.makeText(RadioGroupActivity.this,
							"��ѡ����" + Rbtn.getText(), 0).show();
					break;
				case R.id.lunch:
					Toast.makeText(RadioGroupActivity.this,
							"��ѡ����" + Rbtn.getText(), 0).show();
					break;
				case R.id.dinner:
					Toast.makeText(RadioGroupActivity.this,
							"��ѡ����" + Rbtn.getText(), 0).show();
					break;
				case R.id.all:
					Toast.makeText(RadioGroupActivity.this,
							"��ѡ����" + Rbtn.getText(), 0).show();
					break;
				}
			}
		});
		Button clearButton = (Button) findViewById(R.id.clear);
		clearButton.setOnClickListener(this);
		Button showButton = (Button) findViewById(R.id.show_radio);
		showButton.setOnClickListener(this);
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.clear:
			mRadioGroup.clearCheck();
			Button vv = (Button) findViewById(v.getId());
			Toast.makeText(RadioGroupActivity.this, "��ѡ����" + vv.getText(), 0)
					.show();
			break;
		case R.id.show_radio:
			int len = mRadioGroup.getChildCount();
			for (int i = 0; i < len; i++) {
				RadioButton rbtn = (RadioButton) mRadioGroup.getChildAt(i);
				if (rbtn.isChecked()) {
					Toast.makeText(RadioGroupActivity.this,
							"��ѡ����---��" + rbtn.getText(), Toast.LENGTH_SHORT)
							.show();
				}
			}
		}
	}
}
