package com.android.book;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.TransitionDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.ImageView;

public class TransitionDrawabl extends Activity {
	private int change = 0;
	private int[] ids = { R.drawable.image1, R.drawable.image2,
			R.drawable.image3, R.drawable.image4, R.drawable.image5 };
	private Drawable[] drawables;
	private ImageView image;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.transition);
		image = (ImageView) this.findViewById(R.id.image);
		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(getResources(), R.drawable.image1, opts);
		opts.inSampleSize = computeSampleSize(opts, -1, 500 * 500);
		opts.inJustDecodeBounds = false;
		drawables = new Drawable[ids.length];
		try {
			for (int i = 0; i < ids.length; i++) {
				Bitmap bmp = BitmapFactory.decodeResource(getResources(),
						ids[i], opts);
				drawables[i] = new BitmapDrawable(bmp);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		new Thread(new MyRunnable()).start();
		// �����̣߳��ı�transition
	}

	private Handler handler = new Handler(new Handler.Callback() {

		public boolean handleMessage(Message msg) {
			int duration = msg.arg1;
			TransitionDrawable tran = null;
			tran = new TransitionDrawable(new Drawable[] {
					drawables[change % ids.length],
					drawables[(change + 1) % ids.length], });
			change++;
			image.setImageDrawable(tran);
			tran.startTransition(duration);
			return false;
		}
	});

	// �̣߳�ȥ������Ϣ����transitionһֱ�ı�
	private class MyRunnable implements Runnable {

		public void run() {
			while (true) {
				int duration = 3000;
				Message message = handler.obtainMessage();
				message.arg1 = duration;
				handler.sendMessage(message);
				try {
					Thread.sleep(duration);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}

	}

	private int computeSampleSize(BitmapFactory.Options options, int minSide,
			int maxPixels) {
		int size = computeInitialSampleSize(options, minSide, maxPixels);
		int rize;
		if (size <= 8) {
			rize = 1;
			while (rize < size) {
				rize <<= 1;
			}
		} else {
			rize = (size + 7) / 8 * 8;
		}
		return rize;
	}

	private int computeInitialSampleSize(BitmapFactory.Options options,
			int minSide, int maxPixels) {
		double w = options.outWidth;
		double h = options.outHeight;
		int lowerBound = (maxPixels == -1) ? 1 : (int) Math.ceil(Math.sqrt(w
				* h / maxPixels));
		int upperBound = (minSide == -1) ? 128 : (int) Math.min(
				Math.floor(w / minSide), Math.floor(h / minSide));

		if (upperBound < lowerBound) {
			return lowerBound;
		}

		if ((maxPixels == -1) && (minSide == -1)) {
			return 1;
		} else if (minSide == -1) {
			return lowerBound;
		} else {
			return upperBound;
		}
	}

}
