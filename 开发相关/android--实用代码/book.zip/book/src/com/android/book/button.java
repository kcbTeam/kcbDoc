package com.android.book;

import android.app.Activity;
import android.os.Bundle;
import android.view.ActionMode;
import android.view.ActionMode.Callback;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.widget.Button;
import android.widget.PopupMenu;
import android.widget.PopupWindow;

public class button extends Activity {
	private Button mButton1, mButton2;
	private ActionMode mActionMode;// ʹ��actionmode��ɲ˵�����
	private ActionMode.Callback actioncallback = new Callback() {

		public boolean onPrepareActionMode(ActionMode mode, Menu menu) {
			// TODO Auto-generated method stub
			return false;
		}

		public void onDestroyActionMode(ActionMode mode) {
			// TODO Auto-generated method stub
			mActionMode = null;
		}

		public boolean onCreateActionMode(ActionMode mode, Menu menu) {
			// TODO Auto-generated method stub
			getMenuInflater().inflate(R.menu.test_menu, menu);
			return true;
		}

		public boolean onActionItemClicked(ActionMode mode, MenuItem item) {
			// TODO Auto-generated method stub
			return false;
		}
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.button);
		mButton1 = (Button) this.findViewById(R.id.button_xxxxxxxxxxxx);
		mButton2=(Button)this.findViewById(R.id.button_actionmode);
		mButton2.setOnLongClickListener(new OnLongClickListener() {
			public boolean onLongClick(View v) {
				// TODO Auto-generated method stub
				if(mActionMode!=null){
					return false;
				}
				mActionMode=startActionMode(actioncallback);
				v.setSelected(true);
				return true;
			}
		});
		registerForContextMenu(mButton1);
		mButton1.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub

			}
		});
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		switch (item.getItemId()) {
		case R.id.ITEMTEST:
			PopupMenu pp = new PopupMenu(button.this, mButton1);
			getMenuInflater().inflate(R.menu.test_menu, pp.getMenu());
			pp.show();

			break;

		default:
			break;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		MenuInflater inflater = getMenuInflater();
		inflater.inflate(R.menu.test_menu, menu);
	}

	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		return super.onContextItemSelected(item);
	}
}
