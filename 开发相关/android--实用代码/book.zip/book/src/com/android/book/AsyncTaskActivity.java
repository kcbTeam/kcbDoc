package com.android.book;

import java.io.IOException;
import java.net.MalformedURLException;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

public class AsyncTaskActivity extends Activity {
	private ImageView show;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_asynctask);
		show = (ImageView) findViewById(R.id.asynctask_show);
	}

	// ��д�÷�����Ϊ����İ�ť�ṩ�¼���Ӧ����
	public void asynctaskdownload(View source) throws MalformedURLException {
		DownTask task = new DownTask(this);
		task.execute("http://a.hiphotos.baidu.com/image/w%3D2048/sign=43f7d84cb64543a9f51bfdcc2a2f8882/0b7b02087bf40ad19237c15b562c11dfa8ecceb3.jpg");
	}

	class DownTask extends AsyncTask<String, String, Bitmap> {
		// �ɱ䳤�������������AsyncTask.exucute()��Ӧ
		ProgressDialog pdialog;
		// �����¼�Ѿ���ȡ�е�����
		int hasRead = 0;
		Context mContext;

		public DownTask(Context ctx) {
			mContext = ctx;
		}

		@Override
		protected void onPreExecute() {
			pdialog = new ProgressDialog(mContext);
			// ���öԻ���ı���
			pdialog.setTitle("��������ִ����");
			// ���öԻ��� ��ʾ������
			pdialog.setMessage("��������ִ���У�����ȴ�...");

			pdialog.show();
		}

		@Override
		protected Bitmap doInBackground(String... params) {
			// StringBuilder sb = new StringBuilder();
			// try {
			// URLConnection conn = params[0].openConnection();
			// // ��conn���Ӷ�Ӧ������������������װ��BufferedReader
			// BufferedReader br = new BufferedReader(new InputStreamReader(
			// conn.getInputStream(), "utf-8"));
			// String line = null;
			// while ((line = br.readLine()) != null) {
			// sb.append(line + "\n");
			// hasRead++;
			// publishProgress(hasRead);
			// }
			Bitmap bitmap = null;
			HttpClient httpclient = new DefaultHttpClient();
			HttpGet httpget = new HttpGet(params[0]);
			try {
				HttpResponse httpresponse = httpclient.execute(httpget);
				if (httpresponse.getStatusLine().getStatusCode() == 200) {
					HttpEntity he = httpresponse.getEntity();
					byte[] data = EntityUtils.toByteArray(he);
					bitmap = BitmapFactory
							.decodeByteArray(data, 0, data.length);
				}
			} catch (ClientProtocolException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			return bitmap;
		}

		@Override
		protected void onPostExecute(Bitmap result) {
			// ����HTMLҳ�������
			show.setImageBitmap(result);
			pdialog.dismiss();
		}

		@Override
		protected void onProgressUpdate(String... values) {
			// TODO Auto-generated method stub
			super.onProgressUpdate(values);
		}
	}
}