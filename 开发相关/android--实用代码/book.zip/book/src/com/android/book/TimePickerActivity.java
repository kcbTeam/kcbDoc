package com.android.book;

/*
 * 
 * author:fird_chen
 * */
import android.app.Activity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.widget.AnalogClock;
import android.widget.TimePicker;
import android.widget.TimePicker.OnTimeChangedListener;

public class TimePickerActivity extends Activity {

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("TimePickerActivity");
		setContentView(R.layout.time_picker);
		TimePicker tp = (TimePicker) this.findViewById(R.id.time_picker);
		tp.setIs24HourView(true);
		AnalogClock mAnologclock = (AnalogClock) this
				.findViewById(R.id.anologclock);
		tp.setOnTimeChangedListener(new listener());
		mAnologclock.setOnTouchListener(new OnTouchListener() {

			public boolean onTouch(View v, MotionEvent event) {
				// TODO Auto-generated method stub
				return false;
			}
		});
		/*
		 * ����һ��ģ��ʱ�ӿؼ�ΪAnalogClock����api��
		 */

	}

	public class listener implements OnTimeChangedListener {

		public void onTimeChanged(TimePicker view, int hourOfDay, int minute) {
			// TODO Auto-generated method stub
			System.out.println(view.getCurrentHour());
			System.out.println(view.getCurrentMinute());
//			System.out.println(hourOfDay);
//			System.out.println(minute);

		}

	}
}