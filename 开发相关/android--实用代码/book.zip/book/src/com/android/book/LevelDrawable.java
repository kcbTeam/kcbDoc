package com.android.book;

import android.os.Bundle;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.BitmapFactory.Options;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.LevelListDrawable;
import android.view.Menu;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

public class LevelDrawable extends Activity {
	private int[] ids = { R.drawable.image1, R.drawable.image2,
			R.drawable.image3, R.drawable.image4, R.drawable.image5 };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.leveldrawable);
		final ImageView image = (ImageView) this.findViewById(R.id.image);
		BitmapFactory.Options opts = new BitmapFactory.Options();
		opts.inJustDecodeBounds = true;
		BitmapFactory.decodeResource(getResources(), R.drawable.image1, opts);
		opts.inSampleSize = computeSampleSize(opts, -1, 500 * 500);
		opts.inJustDecodeBounds = false;
		LevelListDrawable level = new LevelListDrawable();
		// ����һ��LevelListDrawable
		try {
			for (int i = 0; i < ids.length; i++) {
				// forѭ��������5��drawable��Դ
				Bitmap map = BitmapFactory.decodeResource(getResources(),
						ids[i], opts);
				BitmapDrawable bitmap = new BitmapDrawable(map);
				level.addLevel(i, i + 1, bitmap);// ���ӵ�LevelListDrawable
			}
			image.setImageDrawable(level);
		} catch (OutOfMemoryError err) {
			err.printStackTrace();
		}
		image.setImageLevel(1);// Ĭ�ϵ�levelΪ0����������Ϊ1
		Button button = (Button) this.findViewById(R.id.button_level2);
		button.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				int i = image.getDrawable().getLevel();
				if (i >= 5) {
					i = 0;
				}
				image.getDrawable().setLevel(++i);// �ı�level
			}
		});
	}

	public static int computeSampleSize(BitmapFactory.Options options,
			int minSize, int maxPixels) {
		int size = computeInitialSampleSize(options, minSize, maxPixels);
		int rize;
		if (size <= 8) {
			rize = 1;
			while (rize < size) {
				rize <<= 1;
			}
		} else {
			rize = (size + 7) / 8 * 8;
		}
		return rize;
	}

	private static int computeInitialSampleSize(Options options, int minSize,
			int maxPixels) {
		double w = options.outWidth;
		double h = options.outHeight;
		int lowerBound = (maxPixels == -1) ? 1 : (int) Math.ceil(Math.sqrt(w
				* h / maxPixels));
		int upperBound = (minSize == -1) ? 128 : (int) Math.min(
				Math.floor(w / minSize), Math.floor(h / minSize));
		if (upperBound < lowerBound) {
			return lowerBound;
		}
		if ((maxPixels == -1) && (minSize == -1)) {
			return 1;
		} else if (minSize == -1) {
			return lowerBound;
		} else {
			return upperBound;
		}
	}
}
