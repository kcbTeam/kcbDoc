package com.android.book;
/*
 * 
 * author:fird_chen
 * */
import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class EditTextActivity extends Activity {
	/** Called when the activity is first created. */
	private Button get_edit_view_button, test_button;
	private EditText edit_text2;
	private EditText edit_text;
    
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("EditTextActivity");
		setContentView(R.layout.editview);

		test_button = (Button) this.findViewById(R.id.test_button_test);
		edit_text2 = (EditText) this.findViewById(R.id.test_edittext_test);
		edit_text = (EditText) findViewById(R.id.edit_text);
		test_button.setOnClickListener(new OnClickListener() {
			public void onClick(View v) {
				System.out.println(edit_text2.getText());
				if (edit_text2.getText().toString().trim().equals("")) {
					edit_text2.setError("����Ϊ�գ�");
					return;
				}
			}
		});

		get_edit_view_button = (Button) this
				.findViewById(R.id.get_edit_view_button);
		get_edit_view_button.setOnClickListener(get_edit_view_button_listener);

	}

	private Button.OnClickListener get_edit_view_button_listener = new Button.OnClickListener() {
		public void onClick(View v) {
			if (edit_text.getText().toString().trim().equals("")) {
				edit_text.setError("����Ϊ�գ�");
				return;
			}
			Toast toast = Toast.makeText(EditTextActivity.this,
					edit_text.getText(), Toast.LENGTH_SHORT);
			toast.setGravity(Gravity.TOP, 1, 200);
			toast.show();
		}
	};

}