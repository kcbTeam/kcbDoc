package com.android.book;

import android.app.Activity;

public class CheckMiMaActivity extends Activity {
        
}
