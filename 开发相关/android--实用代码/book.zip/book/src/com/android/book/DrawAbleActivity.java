package com.android.book;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

public class DrawAbleActivity extends Activity {
	private Button mButton1, mButton2, mButton3;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_drawable);
		mButton1 = (Button) this.findViewById(R.id.button_level_list);
		mButton2 = (Button) this.findViewById(R.id.button_transition);
		mButton3 = (Button) this.findViewById(R.id.button_clipDrawable);
		mButton1.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DrawAbleActivity.this,
						LevelDrawable.class);
				startActivity(intent);
			}
		});
		mButton2.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DrawAbleActivity.this,
						TransitionDrawabl.class);
				startActivity(intent);

			}
		});
		mButton3.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				// TODO Auto-generated method stub
				Intent intent = new Intent(DrawAbleActivity.this,
						clipdrawable.class);
				startActivity(intent);

			}
		});
	}
}
