package com.android.book;

/*
 * 
 * author:fird_chen
 * */

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;
import android.widget.MultiAutoCompleteTextView;

public class AutoCompleteTextViewActivity extends Activity {
	private static final String[] COUNTRIES = new String[] { "China", "Russia",
			"Germany", "Ukraine", "Belarus", "USA", "China1", "China12",
			"Germany", "Russia2", "Belarus", "USA" };

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.autocomplete);
		setTitle("AutoCompleteTextViewActivity");
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(this,
				android.R.layout.simple_dropdown_item_1line, COUNTRIES);
		AutoCompleteTextView textView = (AutoCompleteTextView) findViewById(R.id.auto_complete);
		textView.setAdapter(adapter);
		MultiAutoCompleteTextView textview2 = (MultiAutoCompleteTextView) this
				.findViewById(R.id.multiauto_complete);
		textview2.setAdapter(adapter);
		textview2.setTokenizer(new MultiAutoCompleteTextView.CommaTokenizer());
	}
}
