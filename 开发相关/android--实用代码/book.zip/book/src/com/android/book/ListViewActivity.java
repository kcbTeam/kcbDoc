package com.android.book;

/*
 * 
 * author:fird_chen
 * */
import java.util.ArrayList;
import java.util.HashMap;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

public class ListViewActivity extends Activity {
	private ListView listview = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.listview);
		listview = (ListView) findViewById(R.id.listview);
		ArrayList<HashMap<String, Object>> list = new ArrayList<HashMap<String, Object>>();
		HashMap<String, Object> map1 = new HashMap<String, Object>();
		HashMap<String, Object> map2 = new HashMap<String, Object>();
		HashMap<String, Object> map3 = new HashMap<String, Object>();
		map1.put("user_name", "zhangsan");
		map1.put("user_ip", "192.168.0.1");
		map1.put("pic", R.drawable.won);
		map2.put("user_name", "lisi");
		map2.put("user_ip", "192.168.0.2");
		map2.put("pic", R.drawable.won);
		map3.put("user_name", "wangwu");
		map3.put("user_ip", "192.168.0.3");
		map3.put("pic", R.drawable.won);
		list.add(map1);
		list.add(map2);
		list.add(map3);
		SimpleAdapter listAdapter = new SimpleAdapter(this, list, R.layout.own,
				new String[] { "user_name", "user_ip", "pic" }, new int[] {
						R.id.user_name, R.id.user_ip, R.id.imageview });
		listview.setAdapter(listAdapter);
		listview.setOnItemClickListener(new OnItemClickListener() {
			public void onItemClick(AdapterView<?> parent, View view,
					int position, long id) {
				TextView tx_ip = (TextView) view.findViewById(R.id.user_ip);
				TextView tx_user = (TextView) view.findViewById(R.id.user_name);
				System.out.println(tx_ip.getText());
				System.out.println(tx_user.getText());
				System.out.println("id----------------" + id);
				System.out.println("position----------" + position);
			}
		});
	}
}
