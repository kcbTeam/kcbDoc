package com.android.book;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

/*
 *author:Frid_Chen
 *
 *��̬�޸�view
 */
public class AddView extends Activity implements OnClickListener {
    private EditText work;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.addview);
        work = (EditText) this.findViewById(R.id.work);
        TextView text_add_tx = (TextView) findViewById(R.id.add);
        text_add_tx.setOnClickListener(this);
    }

    public void onClick(View v) {
        // TODO Auto-generated method stub
        switch (v.getId()) {
        case R.id.add:
            final LinearLayout mLineraLayout11 = (LinearLayout) findViewById(R.id.add_view);
            View itemview = View.inflate(this, R.layout.grid, null);
            if (!"".equals(work.getText().toString().trim())) {
                mLineraLayout11.addView(itemview);
                TextView tx = (TextView) itemview
                        .findViewById(R.id.add_textview);
                TextView delete = (TextView) itemview.findViewById(R.id.delete);
                delete.setOnClickListener(new OnClickListener() {

                    public void onClick(View v) {
                        LinearLayout ll = (LinearLayout) v.getParent();
                      //  TextView tx_n = (TextView) ll.getChildAt(0);
                        // TextView tx_n = (TextView) ll
                        // .findViewById(R.id.add_textview);
                        mLineraLayout11.removeView(ll);
                    }
                });
                tx.setText(work.getText().toString().trim());
                work.setText("");
                // tx.setGravity(Gravity.LEFT);
                tx.setTextSize(10);
               // String xxx = tx.getText().toString();
            } else {
                Toast.makeText(AddView.this, "�༭������Ϊ�գ�", Toast.LENGTH_SHORT)
                        .show();
            }
            break;
        }
    }
}
