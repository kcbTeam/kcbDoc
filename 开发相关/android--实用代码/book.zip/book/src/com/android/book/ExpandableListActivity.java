package com.android.book;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.os.Bundle;
import android.view.View;
import android.widget.ExpandableListView;
import android.widget.SimpleExpandableListAdapter;
import android.widget.TextView;
import android.widget.Toast;



/*
 * author:Frid_Chen
 * 
 * ��Ͽ��demo
 * 
 * 
 */

public class ExpandableListActivity extends android.app.ExpandableListActivity {
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_expandablelistactivity);
		List<Map<String, String>> list = new ArrayList<Map<String, String>>();// ����
		Map<String, String> map1 = new HashMap<String, String>();
		map1.put("group", "����");
		Map<String, String> map2 = new HashMap<String, String>();
		map2.put("group", "����");
		list.add(map1);
		list.add(map2);

		List<Map<String, String>> listChild1 = new ArrayList<Map<String, String>>();// child
		Map<String, String> map3 = new HashMap<String, String>();
		map3.put("country", "�й�");
		listChild1.add(map3);
		Map<String, String> map4 = new HashMap<String, String>();
		map4.put("country", "����");
		listChild1.add(map4);

		List<Map<String, String>> listChild2 = new ArrayList<Map<String, String>>();// child
		Map<String, String> map5 = new HashMap<String, String>();
		map5.put("country", "����");
		listChild2.add(map5);
		Map<String, String> map6 = new HashMap<String, String>();
		map6.put("country", "Ӣ��");
		listChild2.add(map6);

		List<List<Map<String, String>>> childs = new ArrayList<List<Map<String, String>>>();// ������child����ļ�����
		childs.add(listChild1);
		childs.add(listChild2);
		SimpleExpandableListAdapter adapter = new SimpleExpandableListAdapter(
				this, list, R.layout.group, new String[] { "group" },
				new int[] { R.id.tv_group }, childs, R.layout.child,
				new String[] { "country" }, new int[] { R.id.tv_child });
		setListAdapter(adapter);// ������
	}

	@Override
	public boolean onChildClick(ExpandableListView parent, View v,
			int groupPosition, int childPosition, long id) {
		TextView tx = (TextView) v.findViewById(R.id.tv_child);
		System.out.println(tx.getText());
		System.out.println("����������" + groupPosition + "�еĺ���" + childPosition);
		// Toast.makeText(this,
		// "Ƕ���б�������������б���λ" + groupPosition + "�����б���λ" + childPosition,
		// Toast.LENGTH_LONG).show();
		return super.onChildClick(parent, v, groupPosition, childPosition, id);
	}

	@Override
	public void onGroupCollapse(int groupPosition) {
		Toast.makeText(this, "��" + groupPosition + "����", Toast.LENGTH_SHORT)
				.show();
		super.onGroupCollapse(groupPosition);
	}

	@Override
	public void onGroupExpand(int groupPosition) {
		Toast.makeText(this, "��" + groupPosition + "չ��", Toast.LENGTH_SHORT)
				.show();
		super.onGroupExpand(groupPosition);
	}
}
