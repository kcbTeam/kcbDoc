package com.android.book;

/*
 * 
 * author:fird_chen
 * */
import android.app.Activity;
import android.app.DatePickerDialog;
import android.app.DatePickerDialog.OnDateSetListener;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.DatePicker.OnDateChangedListener;

public class DatePickerActivity extends Activity implements OnClickListener {
	private Button mButton;
	private static final int data_pick_id = 1;

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("DataPickActivity");
		setContentView(R.layout.date_picker);
		DatePicker dp = (DatePicker) this.findViewById(R.id.date_picker);
		mButton = (Button) findViewById(R.id.button_data_picker);
		mButton.setOnClickListener(this);
		dp.init(2009, 5, 17, null);
	}

	public class listener implements OnDateChangedListener {
		public void onDateChanged(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			System.out.println(year);
			System.out.println(monthOfYear);
		}
	}

	@SuppressWarnings("deprecation")
	public void onClick(View v) {
		// TODO Auto-generated method stub
		if (v.getId() == R.id.button_data_picker) {
			showDialog(data_pick_id);
		}

	}

	OnDateSetListener listener = new OnDateSetListener() {

		public void onDateSet(DatePicker view, int year, int monthOfYear,
				int dayOfMonth) {
			// TODO Auto-generated method stub
			System.out.println(year + "-" + monthOfYear + "-" + dayOfMonth);
		}
	};

	@Override
	protected android.app.Dialog onCreateDialog(int id) {
		switch (id) {
		case data_pick_id:
			return new DatePickerDialog(this, listener, 2013, 11, 12);
		}
		return null;
	}
}