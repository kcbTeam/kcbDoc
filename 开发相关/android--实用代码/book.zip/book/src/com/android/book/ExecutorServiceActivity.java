package com.android.book;

import java.io.IOException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import android.app.Activity;
import android.app.ProgressDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

public class ExecutorServiceActivity extends Activity implements
		OnClickListener {
	private Button btn01;
	private ImageView image1, image2, image3, image4;
	private int ExecutorService_Count = 0;
	private String image_path1 = "http://a.hiphotos.baidu.com/image/w%3D2048/sign=43f7d84cb64543a9f51bfdcc2a2f8882/0b7b02087bf40ad19237c15b562c11dfa8ecceb3.jpg";
	private String image_path2 = "http://g.hiphotos.baidu.com/image/w%3D2048/sign=2534e71f63d9f2d3201123ef9dd48813/0d338744ebf81a4c0fcf3437d62a6059242da64b.jpg";
	private String image_path3 = "http://a.hiphotos.baidu.com/image/w%3D2048/sign=f9399e3e83025aafd33279cbcfd5aa64/8601a18b87d6277fb605eac629381f30e924fc3d.jpg";
	private String image_path4 = "http://f.hiphotos.baidu.com/image/w%3D2048/sign=40ab5bce3bf33a879e6d071af2641238/55e736d12f2eb9380ec2a20cd4628535e4dd6fa5.jpg";
	private ProgressDialog pd = null;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(android.os.Message msg) {
			Bitmap bitmap = null;
			byte[] data = (byte[]) msg.obj;
			bitmap = BitmapFactory.decodeByteArray(data, 0, data.length);
			switch (msg.what) {
			case 1:
				ExecutorService_Count--;
				System.out.println(ExecutorService_Count);
				image1.setImageBitmap(bitmap);
				if (ExecutorService_Count == 0) {
					pd.dismiss();
				}

				break;
			case 2:
				ExecutorService_Count--;
				System.out.println(ExecutorService_Count);
				image2.setImageBitmap(bitmap);
				if (ExecutorService_Count == 0) {
					pd.dismiss();
				}
				break;
			case 3:
				ExecutorService_Count--;
				System.out.println(ExecutorService_Count);
				image3.setImageBitmap(bitmap);
				if (ExecutorService_Count == 0) {
					pd.dismiss();
				}
				break;
			case 4:
				ExecutorService_Count--;
				System.out.println(ExecutorService_Count);
				BitmapDrawable bd = new BitmapDrawable(bitmap);
				image4.setBackgroundDrawable(bd);
				if (ExecutorService_Count == 0) {
					pd.dismiss();
				}
				end();
				break;
			default:
				pd.dismiss();
				Toast.makeText(ExecutorServiceActivity.this, "�������",
						Toast.LENGTH_SHORT).show();
				break;
			}
		};
	};

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.layout_executorservice);
		btn01 = (Button) this.findViewById(R.id.button_ExecutorService);
		btn01.setOnClickListener(this);
		image1 = (ImageView) this.findViewById(R.id.image1_ExecutorService);
		image2 = (ImageView) this.findViewById(R.id.image2_ExecutorService);
		image3 = (ImageView) this.findViewById(R.id.image3_ExecutorService);
		image4 = (ImageView) this.findViewById(R.id.image4_ExecutorService);
	}

	protected void end() {
		// TODO Auto-generated method stub
		pd.dismiss();
	}

	public void onClick(View v) {
		// TODO Auto-generated method stub
		pd = new ProgressDialog(this);
		pd.setTitle("�����С�������");
		pd.setMessage("�����ģ�");
		pd.show();
		ExecutorService pool = Executors.newFixedThreadPool(2);
		pool.execute(new Thread(new Runnable() {
			public void run() {
				ExecutorService_Count++;
				System.out.println(ExecutorService_Count);
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				HttpGet httpget = new HttpGet(image_path1);
				byte[] data = null;
				try {
					HttpResponse httpresponse = httpclient.execute(httpget);
					if (httpresponse.getStatusLine().getStatusCode() == 200) {
						HttpEntity he = httpresponse.getEntity();
						data = EntityUtils.toByteArray(he);
					}
					Message msg = Message.obtain();
					msg.obj = data;
					msg.what = 1;
					myHandler.sendMessage(msg);
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}));
		pool.execute(new Thread(new Runnable() {
			public void run() {
				ExecutorService_Count++;
				System.out.println(ExecutorService_Count);
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				HttpGet httpget = new HttpGet(image_path2);
				byte[] data = null;
				try {
					HttpResponse httpresponse = httpclient.execute(httpget);
					if (httpresponse.getStatusLine().getStatusCode() == 200) {
						data = EntityUtils.toByteArray(httpresponse.getEntity());
					}
					Message msg = Message.obtain();
					msg.obj = data;
					msg.what = 2;
					myHandler.sendMessage(msg);
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}));
		pool.execute(new Thread(new Runnable() {
			public void run() {
				ExecutorService_Count++;
				System.out.println(ExecutorService_Count);
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				HttpGet httpget = new HttpGet(image_path3);
				byte[] data = null;
				try {
					HttpResponse httpresponse = httpclient.execute(httpget);
					if (httpresponse.getStatusLine().getStatusCode() == 200) {
						HttpEntity he = httpresponse.getEntity();
						data = EntityUtils.toByteArray(he);
					}
					Message msg = Message.obtain();
					msg.obj = data;
					msg.what = 3;
					myHandler.sendMessage(msg);
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}));
		pool.execute(new Thread(new Runnable() {
			public void run() {
				ExecutorService_Count++;
				System.out.println(ExecutorService_Count);
				// TODO Auto-generated method stub
				HttpClient httpclient = new DefaultHttpClient();
				HttpGet httpget = new HttpGet(image_path4);
				byte[] data = null;
				try {
					HttpResponse httpresponse = httpclient.execute(httpget);
					if (httpresponse.getStatusLine().getStatusCode() == 200) {
						HttpEntity he = httpresponse.getEntity();
						data = EntityUtils.toByteArray(he);
					}
					Message msg = Message.obtain();
					msg.obj = data;
					msg.what = 4;
					myHandler.sendMessage(msg);
				} catch (ClientProtocolException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}));
	}
}
