package com.android.book;

/*
 * 
 * author:fird_chen
 * */

import android.app.Activity;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;

public class SeekBarActivity extends Activity implements
		OnSeekBarChangeListener {
	private SeekBar mSeerbBar = null;
	private TextView mTextView1, mTextView2 = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("SeekBarActivity");
		setContentView(R.layout.seek_bar);
		mSeerbBar = (SeekBar) findViewById(R.id.seek);
		mTextView1 = (TextView) findViewById(R.id.seekbar_textview1);
		mTextView2 = (TextView) findViewById(R.id.seekbar_textview2);
		mSeerbBar.setOnSeekBarChangeListener(this);
	}

	public void onProgressChanged(SeekBar seekBar, int progress,
			boolean fromUser) {
		// TODO Auto-generated method stub
		mTextView2.setText("��ǰλ���ǣ�" + progress);
		seekBar.setSecondaryProgress(++progress);

	}

	public void onStartTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		mTextView1.setText("��ʼ��");

	}

	public void onStopTrackingTouch(SeekBar seekBar) {
		// TODO Auto-generated method stub
		mTextView1.setText("������");

	}
}