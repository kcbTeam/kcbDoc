package com.android.book;

import java.util.Timer;
import java.util.TimerTask;


import android.app.ActionBar;
import android.app.ActionBar.Tab;
import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentTransaction;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.Toast;


public class ActionBarActivity extends Activity implements
		ActionBar.TabListener, ActionBar.OnNavigationListener {

	private ActionBar actionBar;
	private Button tabs;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.actionbar_layout);
		actionBar = this.getActionBar();
		if (actionBar != null) {
			// icon���ʹ��
			actionBar.setDisplayHomeAsUpEnabled(true);
			actionBar.setDisplayShowTitleEnabled(true);
			actionBar.setIcon(R.drawable.image2);
		}
		tabs = (Button) findViewById(R.id.tabs);
		tabs.setOnClickListener(new View.OnClickListener() {

			public void onClick(View v) {
				actionBar.setTitle("ѡ�");
				actionBar.setNavigationMode(ActionBar.NAVIGATION_MODE_TABS);
				if (actionBar.getTabCount() == 0) {
					actionBar.addTab(actionBar.newTab().setText("Tab1")
							.setTabListener(ActionBarActivity.this));
					actionBar.addTab(actionBar.newTab().setText("Tab2")
							.setTabListener(ActionBarActivity.this));
					actionBar.addTab(actionBar.newTab().setText("Tab3")
							.setTabListener(ActionBarActivity.this));
				}
			}
		});
		this.findViewById(R.id.list_actionbar).setOnClickListener(
				new View.OnClickListener() {
					public void onClick(View v) {
						String[] str = { "1", "2", "3", "4", "5" };
						actionBar.setTitle("�б�");
						actionBar
								.setNavigationMode(ActionBar.NAVIGATION_MODE_LIST);
						actionBar.setListNavigationCallbacks(
								new ArrayAdapter<String>(
										ActionBarActivity.this,
										android.R.layout.simple_spinner_item,
										str), ActionBarActivity.this);
					}
				});
		this.findViewById(R.id.hide_actionbar).setOnClickListener(
				new OnClickListener() {

					public void onClick(View v) {
						// TODO Auto-generated method stub
						actionBar.hide();

					}
				});
		this.findViewById(R.id.show_actionbar).setOnClickListener(
				new OnClickListener() {

					public void onClick(View v) {
						// TODO Auto-generated method stub
						actionBar.show();
					}
				});
		boolean b = false;
		Timer tt = new Timer();
		if (b) {
			tt.schedule(new TimerTask() {

				@Override
				public void run() {
					// TODO Auto-generated method stub

				}
			}, 0, 1200);
		}
		tt.cancel();
	}

	public boolean onCreateOptionsMenu(Menu menu) {
		getMenuInflater().inflate(R.menu.actionbar, menu);
		return true;
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {
		switch (item.getItemId()) {
		case android.R.id.home:
			Toast.makeText(this, "home", 1).show();
			this.finish();
			break;

		case android.R.id.title:
			Toast.makeText(this, "title", 1).show();
			break;
		default:

			break;
		}
		return super.onMenuItemSelected(featureId, item);
	}

	public void onTabReselected(Tab tab, FragmentTransaction ft) {

	}

	public void onTabSelected(Tab tab, FragmentTransaction ft) {
		// switch (tab.getPosition()) {
		// case 0:
		// setContentView(R.layout.actionbar_layout);
		// break;
		// case 2:
		// break;
		// case 1:
		// ActionBarActivity.this.setContentView(R.layout.rating_bar);
		// break;
		// }
	}


	public class DummyFragement extends Fragment {
		@Override
		public View onCreateView(LayoutInflater inflater, ViewGroup container,
				Bundle savedInstanceState) {
			// TODO Auto-generated method stub
			LinearLayout ly = (LinearLayout) ActionBarActivity.this
					.findViewById(R.id.test_andtionbar);
			return ly;

			// return super.onCreateView(inflater, container,
			// savedInstanceState);
		}
	}

	public void onTabUnselected(Tab tab, FragmentTransaction ft) {

	}

	public boolean onNavigationItemSelected(int itemPosition, long itemId) {

		// switch (itemPosition) {
		// case 0:
		// ActionBarActivity.this.setContentView(R.layout.actionbar_layout);
		// break;
		// case 2:
		// break;
		// case 1:
		// ActionBarActivity.this.setContentView(R.layout.rating_bar);
		// break;
		// }
		return false;
	}
}
