package com.android.book;

/*
 * 
 * author:fird_chen
 * */

import android.app.Activity;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.ToggleButton;

public class ToggleButtonView extends Activity {
	private ToggleButton toggle;
	private Switch mSwitch;
	LinearLayout mLinearLayout;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.togglebuttonview);
		toggle = (ToggleButton) findViewById(R.id.toggle);
		mSwitch = (Switch) findViewById(R.id.switcher);
		mLinearLayout = (LinearLayout) findViewById(R.id.test);
		OnCheckedChangeListener listener = new OnCheckedChangeListener() {
			public void onCheckedChanged(CompoundButton button,
					boolean isChecked) {
				if (isChecked) {
					// ����LinearLayout��ֱ����
					mLinearLayout.setOrientation(1);
					mSwitch.setTextOff(null);
				} else {
					// ����LinearLayoutˮƽ����
					mLinearLayout.setOrientation(0);
					mSwitch.setTextOn(null);
				}
			}
		};
		toggle.setOnCheckedChangeListener(listener);
		mSwitch.setOnCheckedChangeListener(listener);
	}

	class MyListener implements OnCheckedChangeListener {

		public void onCheckedChanged(CompoundButton buttonView,
				boolean isChecked) {
			if (isChecked) {
				// ����LinearLayout��ֱ����
				mLinearLayout.setOrientation(LinearLayout.VERTICAL);
			} else {
				// ����LinearLayoutˮƽ����
				mLinearLayout.setOrientation(LinearLayout.HORIZONTAL);
			}
		}
	}
}
