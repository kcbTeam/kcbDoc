package com.android.book;

/*
 * 
 * author:fird_chen
 * */

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;

public class ProgressBarActivity extends Activity implements
		View.OnClickListener {
	private Button mButton, m_Butotn01, m_Button02;
	private ProgressBar mProgressBar;
	private Thread tt;
	private Boolean running = true;
	private Handler myHandler = new Handler() {
		@Override
		public void handleMessage(Message msg) {
			// TODO Auto-generated method stub
			Bundle b = msg.getData();
			mProgressBar.setProgress(b.getInt("progress") + 10);
			mProgressBar.setSecondaryProgress(b.getInt("progress") + 12);
			super.handleMessage(msg);
		}

	};

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("ProgressBarActivity");
		setContentView(R.layout.progress_bar);
		mButton = (Button) findViewById(R.id.button_progress);
		m_Butotn01 = (Button) findViewById(R.id.button_progress01);
		m_Button02 = (Button) findViewById(R.id.button_progress02);
		mProgressBar = (ProgressBar) findViewById(R.id.progress_horizontal);
		mButton.setOnClickListener(this);
		m_Butotn01.setOnClickListener(this);
		m_Button02.setOnClickListener(this);
		tt = new Thread(new Runnable() {
			public void run() {
				for (int i = 0; i < 100; i += 10) {
					if (running) {
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
							System.out.println("�߳�˯������");
						}
						Message msg = new Message();
						Bundle b = new Bundle();
						b.putInt("progress", i);
						msg.setData(b);
						ProgressBarActivity.this.myHandler.sendMessage(msg);
					}
				}
			}
		});
	}

	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.button_progress:
			mProgressBar.setProgress(mProgressBar.getProgress() + 10);
			mProgressBar.setSecondaryProgress(mProgressBar.getProgress() + 12);
			break;
		case R.id.button_progress01:
			// myHandler.post(tt);
			if (tt.isAlive()) {
				running = true;

			} else {
				running = true;
				tt.start();
			}
			break;
		case R.id.button_progress02:
			running = false;
			mProgressBar.setProgress(0);
			mProgressBar.setSecondaryProgress(0);
		}

	}

}
