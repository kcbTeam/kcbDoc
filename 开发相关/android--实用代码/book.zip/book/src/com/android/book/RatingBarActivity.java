package com.android.book;

/*
 * 
 * author:fird_chen
 * */

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.RatingBar.OnRatingBarChangeListener;
import android.widget.TextView;
import android.widget.Toast;

public class RatingBarActivity extends Activity implements OnClickListener {
	private RatingBar mRatingBar = null;
	private Button mButton, mButton_clear;
	private TextView mTextView = null;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setTitle("RatingBarActivity");
		setContentView(R.layout.rating_bar);
		mRatingBar = (RatingBar) findViewById(R.id.rating_bar);
		mButton = (Button) this.findViewById(R.id.button_rating);
		mTextView = (TextView) this.findViewById(R.id.textview_rating);
		mButton_clear = (Button) this.findViewById(R.id.button_set_rating);
		mButton_clear.setOnClickListener(this);
		mButton.setOnClickListener(this);
		mRatingBar
				.setOnRatingBarChangeListener(new OnRatingBarChangeListener() {
					public void onRatingChanged(RatingBar ratingBar,
							float rating, boolean fromUser) {
						// TODO Auto-generated method stub
						mTextView.setText("��ǰ������Ϊ" + rating
								+ "��ǰ��ratingbar��idΪ��" + ratingBar.getId());
						if (rating == 5) {
							new AlertDialog.Builder(RatingBarActivity.this).setMessage("��ϲ�������ְ���").show();
						}
					}
				});
	}

	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.button_rating:
			Toast.makeText(RatingBarActivity.this,
					"����Ϊ" + mRatingBar.getRating() + "���ǣ�", Toast.LENGTH_SHORT)
					.show();
			new AlertDialog.Builder(RatingBarActivity.this).setMessage("��ϲ�������ְ���").show();
			break;
		case R.id.button_set_rating:
			mRatingBar.setRating(0);
			break;
		}

	}
}