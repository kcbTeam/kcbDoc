package com.example.animation;

import android.app.ActionBar;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;

import com.android.book.R;

/**
 * ��������
 * 
 * @author fird_chen
 */

public class AnimationExampleActivity extends Activity implements
		OnClickListener {

	Button btn_alpha;// ����͸���ȶ���Ч��
	Button btn_scale; // ����ߴ���������Ч��
	Button btn_translate;// ����ת��λ���ƶ�����Ч��
	Button btn_rotate;// ����ת����ת����Ч��

	/** Called when the activity is first created. */
	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main_animation);
		getView();
		setOnclikListener();
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// TODO Auto-generated method stub
		getMenuInflater().inflate(R.menu.activity_main, menu);
		return true;
	}

	private void getView() {
		btn_alpha = (Button) findViewById(R.id.btn_alpha);
		btn_scale = (Button) findViewById(R.id.btn_scale);
		btn_translate = (Button) findViewById(R.id.btn_translate);
		btn_rotate = (Button) findViewById(R.id.btn_rotate);
	}

	private void setOnclikListener() {
		btn_alpha.setOnClickListener(this);
		btn_scale.setOnClickListener(this);
		btn_translate.setOnClickListener(this);
		btn_rotate.setOnClickListener(this);
	}

	public void onClick(View v) {
		Intent intent;
		switch (v.getId()) {
		case R.id.btn_alpha:
			intent = new Intent(AnimationExampleActivity.this,
					AnimationAlphaActivity.class);
			startActivity(intent);
			break;
		case R.id.btn_scale:
			intent = new Intent(AnimationExampleActivity.this,
					AnimationScaleActivity.class);
			startActivity(intent);
			break;
		case R.id.btn_translate:
			intent = new Intent(AnimationExampleActivity.this,
					AnimationTranslateActivity.class);
			startActivity(intent);
			break;
		case R.id.btn_rotate:
			intent = new Intent(AnimationExampleActivity.this,
					AnimationRotateActivity.class);
			startActivity(intent);
			break;
		default:
			break;
		}

	}
}