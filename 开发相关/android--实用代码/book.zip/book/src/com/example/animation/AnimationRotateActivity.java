package com.example.animation;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationSet;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.android.book.R;

/**
 * ����ת����ת����Ч��
 * 
 * @author fird_chen
 */
public class AnimationRotateActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.an_rotate);
		ImageView imgv = (ImageView) findViewById(R.id.img);
		Animation alphaAnimation = AnimationUtils.loadAnimation(this,
				R.anim.rotate);
		AnimationSet tt =new AnimationSet(true);
		tt.addAnimation(alphaAnimation);
		imgv.startAnimation(tt);
	}
}
