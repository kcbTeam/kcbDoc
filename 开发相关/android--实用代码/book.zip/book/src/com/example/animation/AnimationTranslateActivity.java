package com.example.animation;

import android.app.Activity;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import com.android.book.R;

/**
 * ����ת��λ���ƶ�����Ч��
 * 
 * @author fird_chen
 */
public class AnimationTranslateActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.an_translate);
		ImageView imgv = (ImageView) findViewById(R.id.img);
		ImageView imgv2 = (ImageView) findViewById(R.id.animation_test);
		Animation alphaAnimation = AnimationUtils.loadAnimation(this,
				R.anim.translate);
		imgv.startAnimation(alphaAnimation);
		imgv2.setImageResource(R.drawable.animation_test1);
		
		AnimationDrawable xx = (AnimationDrawable) imgv2.getDrawable();
		xx.start();
	}
}
