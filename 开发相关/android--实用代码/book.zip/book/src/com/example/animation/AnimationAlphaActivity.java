package com.example.animation;

import android.app.Activity;
import android.os.Bundle;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.LayoutAnimationController;
import android.widget.ImageView;

import com.android.book.R;

/**
 * ����͸���ȶ���Ч��
 * 
 * @author:fird_chen
 * 
 */

public class AnimationAlphaActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.an_alpha);
		ImageView imgv = (ImageView) findViewById(R.id.img);
		Animation alphaAnimation = AnimationUtils.loadAnimation(this,R.anim.alpha);
		alphaAnimation.setInterpolator(new AccelerateDecelerateInterpolator());
		imgv.startAnimation(alphaAnimation);	
		LayoutAnimationController lac =new LayoutAnimationController(alphaAnimation);
	}
}
